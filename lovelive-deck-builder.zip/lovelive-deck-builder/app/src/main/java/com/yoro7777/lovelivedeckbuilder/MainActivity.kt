package com.yoro7777.lovelivedeckbuilder

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

data class Card(
    val id: String,
    val name: String,
    val category: String,
    val group: String,
    val imageUrl: String
)

class MainActivity : Activity() {
    private val allCards = mutableListOf<Card>()
    private val visibleCards = mutableListOf<Card>()
    private val deck = linkedMapOf<String, Pair<Card, Int>>()

    private lateinit var searchBox: EditText
    private lateinit var categorySpinner: Spinner
    private lateinit var cardList: ListView
    private lateinit var deckText: TextView
    private lateinit var countText: TextView
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadCards()
        buildUi()
        refreshCards()
        refreshDeck()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.WHITE)
        }

        val title = TextView(this).apply {
            text = "LoveLive Deck Builder"
            textSize = 24f
            setTextColor(Color.rgb(220, 20, 90))
            setPadding(0, 0, 0, dp(8))
        }
        root.addView(title)

        searchBox = EditText(this).apply {
            hint = "カード名 / ID / グループで検索"
            isSingleLine = true
        }
        root.addView(searchBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        categorySpinner = Spinner(this)
        val categories = listOf("すべて", "メンバー", "ライブ", "エネルギー", "その他")
        categorySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)
        root.addView(categorySpinner)

        countText = TextView(this).apply {
            textSize = 15f
            setPadding(0, dp(6), 0, dp(6))
        }
        root.addView(countText)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        root.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val cardLabel = TextView(this).apply {
            text = "カード一覧（タップで追加）"
            textSize = 18f
        }
        content.addView(cardLabel)

        cardList = ListView(this)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        cardList.adapter = adapter
        content.addView(cardList, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val deckHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val deckLabel = TextView(this).apply {
            text = "デッキ"
            textSize = 18f
        }
        deckHeader.addView(deckLabel, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val clearButton = Button(this).apply { text = "全削除" }
        deckHeader.addView(clearButton)
        content.addView(deckHeader)

        deckText = TextView(this).apply {
            textSize = 14f
            setPadding(dp(6), dp(6), dp(6), dp(6))
            setBackgroundColor(Color.rgb(248, 248, 248))
        }
        val deckScroll = ScrollView(this).apply { addView(deckText) }
        content.addView(deckScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(190)))

        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = refreshCards()
            override fun afterTextChanged(s: Editable?) {}
        })

        categorySpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) = refreshCards()
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }

        cardList.setOnItemClickListener { _, _, position, _ ->
            addCard(visibleCards[position])
        }

        cardList.setOnItemLongClickListener { _, _, position, _ ->
            removeCard(visibleCards[position])
            true
        }

        clearButton.setOnClickListener {
            deck.clear()
            refreshDeck()
            Toast.makeText(this, "デッキを空にしました", Toast.LENGTH_SHORT).show()
        }

        setContentView(root)
    }

    private fun loadCards() {
        try {
            assets.open("cards.csv").bufferedReader().useLines { lines ->
                lines.drop(1).forEach { line ->
                    val cols = parseCsv(line)
                    if (cols.size >= 5) {
                        allCards += Card(cols[0], cols[1], cols[2], cols[3], cols[4])
                    }
                }
            }
        } catch (_: Exception) {
            allCards += Card("SAMPLE-001", "サンプルメンバー", "メンバー", "μ's", "")
        }
    }

    private fun parseCsv(line: String): List<String> {
        val out = mutableListOf<String>()
        val current = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> {
                    current.append('"'); i++
                }
                c == '"' -> quoted = !quoted
                c == ',' && !quoted -> { out += current.toString(); current.clear() }
                else -> current.append(c)
            }
            i++
        }
        out += current.toString()
        return out
    }

    private fun refreshCards() {
        if (!::adapter.isInitialized) return
        val q = searchBox.text?.toString()?.trim()?.lowercase().orEmpty()
        val cat = categorySpinner.selectedItem?.toString() ?: "すべて"
        visibleCards.clear()
        visibleCards += allCards.filter { card ->
            val matchesQuery = q.isBlank() || card.name.lowercase().contains(q) || card.id.lowercase().contains(q) || card.group.lowercase().contains(q)
            val matchesCategory = cat == "すべて" || card.category == cat || (cat == "その他" && card.category !in listOf("メンバー", "ライブ", "エネルギー"))
            matchesQuery && matchesCategory
        }
        adapter.clear()
        adapter.addAll(visibleCards.map { "${it.name}  [${it.id}]\n${it.category} / ${it.group}" })
        adapter.notifyDataSetChanged()
        countText.text = "カード ${visibleCards.size}件 / 全${allCards.size}件　　デッキ ${deck.values.sumOf { it.second }}枚"
    }

    private fun addCard(card: Card) {
        val current = deck[card.id]?.second ?: 0
        if (current >= 4) {
            Toast.makeText(this, "同じカードは4枚までです", Toast.LENGTH_SHORT).show()
            return
        }
        deck[card.id] = card to (current + 1)
        refreshDeck()
    }

    private fun removeCard(card: Card) {
        val current = deck[card.id]?.second ?: return
        if (current <= 1) deck.remove(card.id) else deck[card.id] = card to (current - 1)
        refreshDeck()
    }

    private fun refreshDeck() {
        if (!::deckText.isInitialized) return
        val total = deck.values.sumOf { it.second }
        if (deck.isEmpty()) {
            deckText.text = "まだカードがありません。\nカード一覧をタップして追加してください。\n長押しすると1枚減らせます。"
        } else {
            deckText.text = deck.values
                .groupBy { it.first.category }
                .entries
                .joinToString("\n\n") { (category, items) ->
                    val subtotal = items.sumOf { it.second }
                    buildString {
                        append("■ $category ($subtotal枚)\n")
                        items.sortedBy { it.first.name }.forEach { (card, count) ->
                            append("$count × ${card.name} [${card.id}]\n")
                        }
                    }.trimEnd()
                }
        }
        countText.text = "カード ${visibleCards.size}件 / 全${allCards.size}件　　デッキ ${total}枚"
    }
}
