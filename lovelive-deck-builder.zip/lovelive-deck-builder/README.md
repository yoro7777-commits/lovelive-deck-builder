# LoveLive Deck Builder

ラブライブ！カードゲーム向けのAndroidデッキ作成アプリです。スマホだけでもGitHub Actionsを使ってAPKを生成できます。

## 現在の機能

- カード名・カードID・グループで検索
- メンバー / ライブ / エネルギー / その他で絞り込み
- タップでデッキに追加
- 長押しで1枚削除
- 同一カード4枚制限
- カテゴリ別のデッキ表示
- GitHub ActionsでDebug APKを自動ビルド

## APKを作る方法

1. このプロジェクト一式をGitHubリポジトリのルートへアップロードします。
2. GitHubの **Actions** を開きます。
3. **Build Android APK** を選びます。
4. **Run workflow** → **Run workflow** を押します。
5. 完了した実行を開き、下部の **Artifacts** にある `lovelive-deck-builder-debug` をダウンロードします。
6. ZIPを展開すると `app-debug.apk` が入っています。

## カードデータを増やす

`app/src/main/assets/cards.csv` を編集します。

形式:

```csv
id,name,category,group,imageUrl
LL-001,カード名,メンバー,蓮ノ空,https://example.com/image.jpg
```

大量データにも対応できるようCSV読込式にしています。ただし、公式カード画像・公式データを配布する場合は権利・利用条件を確認してください。
